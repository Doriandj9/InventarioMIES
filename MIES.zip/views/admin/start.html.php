<div class="content-card">
    <a href="/add/bienes">
        <article>
            <header>Ingresar Bienes</header>
            <hr>
            <section>
                Si das click a este cuadro te llevara 
                a la vista donde ingresaras los bienes que 
                desees ingresar
            </section>
        </article>
    </a>
    <a href="/add/custodio">
        <article>
            <header>Generar Custudio</header>
            <hr>
            <section>
                Dale click y podras genrar una nuevo custodio
                a entregar en unos cuantos pasos y de manera facil
            </section>
        </article>
    </a>
</div>