<div>
    No tiene los permisos necesarios para ingresar al contenido <a href="/list/actas">regresar</a>
</div>