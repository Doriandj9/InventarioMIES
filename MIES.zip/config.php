<?php
use aplication\Utiles;
define('DBNAME','mies_inventario');
define('USER','postgres');
define('PASSWORD', Utiles::Encryp('$,#,;,@,!,11,^,21,#'));
